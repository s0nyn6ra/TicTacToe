let currentPlayer = 'x';
let gameBoard = ['', '', '', '', '', '', '', '', ''];
let gameActive = false;

function startGame() {
    gameActive = true;
    currentPlayer = 'x';
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    renderBoard();
}

function cellClick(index) {
    if (gameBoard[index] === '' && gameActive) {
        gameBoard[index] = currentPlayer;
        checkWinner();
        currentPlayer = currentPlayer === 'x' ? 'o' : 'x';
        renderBoard();
    }
}

function checkWinner() {
    const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
        [0, 4, 8], [2, 4, 6] // diagonals
    ];

    for (const pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            alert(`Player ${currentPlayer} wins!`);
            gameActive = false;
            return;
        }
    }

    if (!gameBoard.includes('')) {
        alert('It\'s a tie!');
        gameActive = false;
    }
}

function renderBoard() {
    const boardElement = document.getElementById('board');
    boardElement.innerHTML = '';

    for (let i = 0; i < gameBoard.length; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.textContent = gameBoard[i];
        cell.addEventListener('click', () => cellClick(i));
        boardElement.appendChild(cell);
    }
}


function renderBoard() {
    const boardElement = document.getElementById('board');
    boardElement.innerHTML = '';

    for (let i = 0; i < gameBoard.length; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';

        if (gameBoard[i] === 'x') {
            cell.classList.add('green-player');
        } else if (gameBoard[i] === 'o') {
            cell.classList.add('red-player');
        }

        cell.textContent = gameBoard[i];
        cell.addEventListener('click', () => cellClick(i));
        boardElement.appendChild(cell);
    }
}
